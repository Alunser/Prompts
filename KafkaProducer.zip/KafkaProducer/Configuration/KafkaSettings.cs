namespace KafkaProducer.Configuration;

public class KafkaSettings
{
    public string ClientUser { get; set; } = string.Empty;
    public string ClientPassword { get; set; } = string.Empty;
    public string CaCertLocation { get; set; } = string.Empty;
    public string P12Location { get; set; } = string.Empty;
    public string P12Password { get; set; } = string.Empty;
}

public class SchemaRegistrySettings
{
    public string Url { get; set; } = string.Empty;
    public int RequestTimeoutMs { get; set; } = 5000;
    public int MaxCachedSchemas { get; set; } = 10;
    public bool EnableSslCertificateVerification { get; set; } = false;
}

public class ProducerSettings
{
    public string BrokerUrl { get; set; } = string.Empty;
    public string ClientId { get; set; } = string.Empty;
    public string CompressionType { get; set; } = "Gzip";
    public int BatchNumMessages { get; set; } = 100;
    public int LingerMs { get; set; } = 5;
    public string Acks { get; set; } = "All";
    public string TopicName { get; set; } = string.Empty;
}
