namespace KafkaProducer.Models;

public class RecebimentoMovimentoContabilData
{
    public string codigo_identificacao_movimentacao_financeira { get; set; } = string.Empty;
    public string codigo_pessoa_corporativo { get; set; } = string.Empty;
    public string codigo_tipo_pessoa_titular_recebivel { get; set; } = string.Empty;
    public string numero_centro_custo_debito { get; set; } = string.Empty;
    public string numero_centro_custo_credito { get; set; } = string.Empty;
    public string codigo_identificador_referencia_movimento { get; set; } = string.Empty;
    public int codigo_produto_operacional { get; set; }
    public long identificador_evento_negocio { get; set; }
    public int codigo_empresa { get; set; }
    public double? identificador_grupo { get; set; }
    public double? numero_identificador_cota_cliente { get; set; }
    public string numero_grupo_bem_produto_consorcio { get; set; } = string.Empty;
    public int numero_cota_consorcio { get; set; }
    public int numero_sequencial_versao { get; set; }
    public long numero_contrato { get; set; }
    public string? data_hora_venda { get; set; }
    public string? data_contemplacao_consorcio { get; set; }
    public string? data_entrega_bem_consorcio { get; set; }
    public string? codigo_situacao_cobranca { get; set; }
    public string? data_cancelamento_cota { get; set; }
    public string? codigo_situacao_grupo { get; set; }
    public string codigo_tipo_empresa_origem { get; set; } = string.Empty;
    public string codigo_empresa_origem { get; set; } = string.Empty;
    public string codigo_dependencia_origem { get; set; } = string.Empty;
    public string codigo_tipo_empresa_destino { get; set; } = string.Empty;
    public string codigo_empresa_destino { get; set; } = string.Empty;
    public string codigo_dependencia_destino { get; set; } = string.Empty;
    public string? indicador_status_estorno { get; set; }
    public string sigla_sistema_evento { get; set; } = string.Empty;
    public int? numero_parcela_contrato { get; set; }
    public int? numero_prazo_cota { get; set; }
    public string? data_vencimento_parcela_contrato { get; set; }
    public string data_contabil_transacao { get; set; } = string.Empty;
    public string? indicador_tributacao_imposto { get; set; }
    public double? valor_fundo_comum { get; set; }
    public double? valor_fundo_reserva { get; set; }
    public double? valor_taxa_administracao_paga { get; set; }
    public double? valor_seguro_pagar { get; set; }
    public double? valor_multa_juro_pagar { get; set; }
    public double? valor_multa_juro_administradora { get; set; }
    public double? valor_outro { get; set; }
    public double? valor_total_grupo { get; set; }
    public double? valor_total_demais_parcela { get; set; }
    public double valor_total_lancamento { get; set; }
    public double? valor_total_tributacao { get; set; }
    public string? indicador_tarifa_movimento { get; set; }
    public string? data_operacao_origem { get; set; }
    public string? codigo_tipo_motivo_estorno { get; set; }
    public string? codigo_unico_transacao_origem { get; set; }
    public string codigo_sistema_integrador { get; set; } = string.Empty;
    public string? indicador_grupo_antes_lei { get; set; }
}

public class RecebimentoMovimentoContabil
{
    public RecebimentoMovimentoContabilData data { get; set; } = new();
}
